package com.example.demo.service.impl;

import com.example.demo.model.Employee;
import org.springframework.http.ResponseEntity;

import jakarta.persistence.Entity;

import javax.persistence.criteria.CriteriaBuilder;
import java.util.List;
import java.util.Optional;

public interface EmployeeService {

    List<Employee> getAllEmployees();
    Optional<Employee> getEmployeeByName(String name);
    Employee saveEmployee(Employee employee);
    Optional<Employee> getEmployeeById(long id);
    Optional<Employee> getEmployeeWithHighestSalary();
    void deleteEmployee(long id);
}
