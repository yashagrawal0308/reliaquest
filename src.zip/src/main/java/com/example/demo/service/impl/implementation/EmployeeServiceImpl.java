package com.example.demo.service.impl.implementation;

import com.example.demo.exception.EmployeeNotFoundException;
import com.example.demo.model.Employee;
import com.example.demo.repository.EmployeeRepository;
import com.example.demo.service.impl.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EmployeeServiceImpl implements EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;

    @Override
    public List<Employee> getAllEmployees() {
        return employeeRepository.findAll();
    }

    @Override
    public Optional<Employee> getEmployeeByName(String name) {
        return Optional.ofNullable(employeeRepository.findByName(name).orElseThrow(() -> new EmployeeNotFoundException("Employee not found with name: " + name)));
    }

    @Override
    public Employee saveEmployee(Employee employee) {
        return employeeRepository.save(employee);

    }

    @Override
    public Optional<Employee> getEmployeeById(long id) {
        return Optional.ofNullable(employeeRepository.findById(id).orElseThrow(() -> new EmployeeNotFoundException("Employee not found with ID: " + id)));
    }

    @Override
    public Optional<Employee> getEmployeeWithHighestSalary() {
        return employeeRepository.findEmployeeWithHighestSalary();
    }

    @Override
    public void deleteEmployee(long id) {
        employeeRepository.deleteById(id);
    }

}
