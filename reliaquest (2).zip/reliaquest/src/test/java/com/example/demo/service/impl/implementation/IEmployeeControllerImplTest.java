package com.example.demo.service.impl.implementation;

import com.example.demo.controller.impl.IEmployeeControllerImpl;
import com.example.demo.model.Employee;
import com.example.demo.service.impl.EmployeeService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultMatcher;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.jsonPath;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@SpringBootTest
@AutoConfigureMockMvc
class IEmployeeControllerImplTest {



    private MockMvc mockMvc;

    @Mock
    private EmployeeService employeeService;

    @InjectMocks
    private IEmployeeControllerImpl employeeController;

    @Test
    public void testGetAllEmployees() throws Exception {
        Employee employee1 = new Employee("John Doe", "50000");
        Employee employee2 = new Employee( "Jane Smith", "60000");
        List<Employee> employees = Arrays.asList(employee1, employee2);

        when(employeeService.getAllEmployees()).thenReturn(employees);

        mockMvc.perform(get("/api/employees"))
                .andExpect(status().isOk())
                .andExpect((ResultMatcher) jsonPath("$[0].name").value("John Doe"))
                .andExpect((ResultMatcher) jsonPath("$[1].name").value("Jane Smith"));
    }

    @Test
    public void testGetEmployeesByNameSearch() throws Exception {
        Employee employee = new Employee("John Doe", "50000");

        when(employeeService.getEmployeeByName("John Doe")).thenReturn(Optional.of(employee));

        mockMvc.perform(get("/api/employees/search/John Doe"))
                .andExpect(status().isOk())
                .andExpect((ResultMatcher) jsonPath("$.name").value("John Doe"));
    }

    @Test
    public void testGetAllEmployeesById() throws Exception {
        Employee employee = new Employee( "John Doe", "50000");

        when(employeeService.getEmployeeById(1)).thenReturn(Optional.of(employee));

        mockMvc.perform(get("/api/employees/1"))
                .andExpect(status().isOk())
                .andExpect((ResultMatcher) jsonPath("$.name").value("John Doe"));
    }

    @Test
    public void testGetHighestSalaryOfEmployees() throws Exception {
        Employee employee = new Employee( "John Doe", "50000");

        when(employeeService.getEmployeeWithHighestSalary()).thenReturn(Optional.of(employee));

        mockMvc.perform(get("/api/employees/highestSalary"))
                .andExpect(status().isOk())
                .andExpect(content().string("50000"));
    }

    @Test
    public void testGetTopTenHighestEarningEmployeesNames() throws Exception {
        Employee employee1 = new Employee( "John Doe", "50000");
        Employee employee2 = new Employee( "Jane Smith", "60000");
        List<Employee> employees = Arrays.asList(employee1, employee2);

        when(employeeService.getAllEmployees()).thenReturn(employees);

        mockMvc.perform(get("/api/employees/topTenHighestEarningEmployeeNames"))
                .andExpect(status().isOk())
                .andExpect((ResultMatcher) jsonPath("$[0]").value("Jane Smith"))
                .andExpect((ResultMatcher) jsonPath("$[1]").value("John Doe"));
    }

    @Test
    public void testDeleteEmployeeById() throws Exception {
        doNothing().when(employeeService).deleteEmployee(1L);

        mockMvc.perform(delete("/api/employees/1"))
                .andExpect(status().isNoContent());

        verify(employeeService, times(1)).deleteEmployee(1L);
    }
}

