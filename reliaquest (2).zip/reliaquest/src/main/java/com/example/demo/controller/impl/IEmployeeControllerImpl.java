package com.example.demo.controller.impl;

import com.example.demo.exception.EmployeeNotFoundException;
import com.example.demo.model.Employee;
import com.example.demo.service.impl.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
public class IEmployeeControllerImpl {

    @Autowired
    private EmployeeService employeeService;


    @GetMapping
    ResponseEntity<List<Employee>> getAllEmployees(){
        List<Employee> employees = employeeService.getAllEmployees();
        return ResponseEntity.ok(employees);
    }

    @PostMapping
    public ResponseEntity<Employee> saveEmployee(@RequestBody Employee employee) {
        Employee savedEmployee = employeeService.saveEmployee(employee);
        return new ResponseEntity<>(savedEmployee, HttpStatus.CREATED);
    }

    @GetMapping("/search/{searchString}")
    public ResponseEntity<Employee> getEmployeesByNameSearch(@PathVariable  String searchString) {
        Optional<Employee> employee = Optional.ofNullable(employeeService.getEmployeeByName(searchString).orElseThrow(() -> new EmployeeNotFoundException("Employee not found with name: " + searchString)));
        if (employee.isPresent()) {
            return ResponseEntity.ok(employee.get());
        }
        return ResponseEntity.notFound().build();

    }

    @GetMapping("/{id}")
    public ResponseEntity<Employee> getAllEmployeesById(@PathVariable int id) {
        Optional<Employee> employee = Optional.ofNullable(employeeService.getEmployeeById(id).orElseThrow(() -> new EmployeeNotFoundException("Employee not found with ID: " + id)));
        if (employee.isPresent()) {
            return ResponseEntity.ok(employee.get());
        }
        return ResponseEntity.notFound().build();

    }
    @GetMapping("/highestSalary")
    public ResponseEntity<String> getHighestSalaryOfEmployees() {
        Optional<Employee> employee = employeeService.getEmployeeWithHighestSalary();
        if (employee.isPresent()) {
            return ResponseEntity.ok(employee.get().getSalary());
        }
        return ResponseEntity.notFound().build();

    }

    @GetMapping("/topTenHighestEarningEmployeeNames")
    public ResponseEntity<List<String>> getTopTenHighestEarningEmployeesNames() {
        List<Employee> employees = employeeService.getAllEmployees();
        List<String> topEarningEmployees = employees.stream()
                .sorted((e1, e2) -> Integer.compare(Integer.parseInt(e2.getSalary()), Integer.parseInt(e1.getSalary())))
                .limit(10)
                .map(Employee::getName)
                .collect(Collectors.toList());

        return ResponseEntity.ok(topEarningEmployees);
    }


    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteEmployeeById(@PathVariable long id) {
        employeeService.deleteEmployee(id);
        return ResponseEntity.noContent().build();
    }
}
